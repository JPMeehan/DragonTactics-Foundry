export class DRAGONTACTICS {
}
DRAGONTACTICS.init = {
    defaultCardCompendium: 'dragontactics.action-cards',
    cardTable: 'Action Cards'
};
DRAGONTACTICS.packChoices = {};
DRAGONTACTICS.imagedrop = {
    height: 300
};
