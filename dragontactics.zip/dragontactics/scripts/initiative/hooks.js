Hooks.on('renderCombatTracker', (application, html, options) => { 

    html.find(".combatant").filter((i, el) => {
        console.log($(this).data())

        return $(this).data("selected") == true 
      }).addClass("bloodied");
})