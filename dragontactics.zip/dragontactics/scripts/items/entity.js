

export class DragonTacticsItem extends Item {
    
}